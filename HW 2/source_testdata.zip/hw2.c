#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/* You will need a structure to store the information to be passed to each thread (see "Passing Parameters to Each Thread" in the textbool's project description)*/

/* Declare the thread that checks columns */
void *column_worker(void *param); 	// the function parameter is for the structure you defined
/* You will also need to declare threads that checks rows and 3x3 subgrids */

/* You will need to declare an array of integer values that is visible to each thread. The value in the array (0 or 1) indicates whether the worker thread's number is valid (see "Returning Results to the Parent Thread" in the textbook's project description) */

int main(int argc, char *argv[])
{
	/*You need to assign values to the structure variable. Then you can create multiple worker threads by passing the information using the structure variable*/

	
	/*You need to call pthread_join() for each childer thread so that the parent will wait*/
	
	/* Finally, after all children returns, you can check the status array that is visible to everyone and see if it is valid. You then print out the final checking result*/
	
	

	return 0;
}


/*thread code for child checking all columns*/
void *column_worker(void *params)
{
	

	pthread_exit(0);
}
/* also need to define threads for checking rows and 3x3 subgrids */
